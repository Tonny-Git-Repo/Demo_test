package de.thm.ap.records.model


class Stats(var recordsStat: List<Record>) {

    var sumCrp = 0
    var crpToEnd = 156
    var sumHalfWeighted = 0
    var averageMark= calculateAverageM()
    var listSize = recordsStat.size


    fun setDateForSats(){
        var weigth = 0
        for(item in recordsStat){
            if(item.isHalfWeighted == true){
                sumHalfWeighted++
            }
            sumCrp += item.crp!!

            weigth += item.crp!! * item.mark!!
        }

    }

    fun calculateAverageM() : Int {
        var sum = 0
        var avg  = 0
        var crp = 0
        recordsStat.let {
            it.forEach { sum += if (it.isHalfWeighted) ((it.mark * it.crp) / 2 ) else (it.mark * it.crp)
                crp += if (it.isHalfWeighted) (it.crp / 2 ) else it.crp
            }
            avg = if (sum > 0) sum / crp else 0
        }
        return avg
    }
}