package de.thm.ap.records


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import de.thm.ap.records.databinding.ActivityRecordsBinding
import de.thm.ap.records.model.Record
import de.thm.ap.records.model.Stats
import de.thm.ap.records.persistence.RecordDAO

class RecordsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRecordsBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecordsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recordListView.emptyView = binding.recordListEmptyView
    }

    override fun onStart() {
        super.onStart()
        var records = RecordDAO.get(this).findAll()

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, records)
        binding.recordListView.adapter = adapter

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // Inflate the menu
        // This adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.records, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection
        return when (item.itemId) {

            R.id.action_add -> {
                val i = Intent(this, RecordFormActivity::class.java)
                startActivity(i)

                true
            }

            R.id.action_stats -> {
                var listRecs = RecordDAO.get(this).findAll()
                var stats = Stats(listRecs)
                stats.setDateForSats()
                var alertDia = AlertDialog.Builder(this)
                .setTitle(R.string.stats)
                .setMessage("Leistungen  ${stats.listSize}\n50% Leistungen ${stats.sumHalfWeighted}\nSumme Crp ${stats.sumCrp}\n" +
                        "Crp bis Ziel ${stats.crpToEnd}\nDurchschnitt ${stats.averageMark}%")
                .setNeutralButton(R.string.close, null)
                .show()

                alertDia.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(getColor(R.color.dialogCloseColor));


                true
            }
            else -> super.onOptionsItemSelected(item) 
        }
    }


    fun onSave(view: android.view.View) {
    }
}